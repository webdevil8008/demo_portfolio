import React from 'react';

const Logo: React.FC = () => {
  return (
    <a href="#hero" className="flex items-center">
      <div className="relative w-10 h-10 bg-gradient-to-br from-primary-500 to-primary-700 rounded-lg flex items-center justify-center overflow-hidden group">
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-all duration-300"></div>
        <span className="text-white font-bold text-2xl transform group-hover:scale-110 transition-transform duration-300">D</span>
      </div>
      <span className="ml-2 text-xl font-semibold text-white">Deepak Parcha</span>
    </a>
  );
};

export default Logo;