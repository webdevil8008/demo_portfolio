import React, { useEffect } from 'react';

const Hero: React.FC = () => {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.reveal').forEach(el => {
      observer.observe(el);
    });

    return () => {
      document.querySelectorAll('.reveal').forEach(el => {
        observer.unobserve(el);
      });
    };
  }, []);

  return (
    <section id="hero" className="relative min-h-screen flex items-center bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900">
      <div className="container-custom relative z-10">
        <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
          <div className="reveal mb-4">
            <span className="inline-block px-4 py-1 rounded-full bg-primary-900 text-primary-300 text-sm font-medium mb-6">
              Frontend Developer & UI Expert
            </span>
          </div>
          
          <h1 className="reveal mb-6 font-bold text-4xl md:text-5xl lg:text-6xl bg-clip-text text-transparent bg-gradient-to-r from-white via-gray-100 to-gray-300">
            Crafting Exceptional Digital Experiences
          </h1>
          
          <p className="reveal text-xl text-gray-400 mb-10 max-w-2xl">
            Freelance frontend developer delivering high-quality websites and applications 
            with pixel-perfect designs, smooth interactions, and optimized performance.
          </p>
          
          <div className="reveal flex flex-col sm:flex-row gap-4">
            <a href="#work" className="btn btn-primary">
              View My Work
            </a>
            <a href="#contact" className="btn bg-gray-800 hover:bg-gray-700 text-white">
              Let's Talk
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;