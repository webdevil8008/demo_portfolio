import React, { useEffect } from 'react';

const About: React.FC = () => {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.reveal').forEach(el => {
      observer.observe(el);
    });

    return () => {
      document.querySelectorAll('.reveal').forEach(el => {
        observer.unobserve(el);
      });
    };
  }, []);

  const skills = [
    { name: 'HTML/CSS', percentage: 95 },
    { name: 'JavaScript', percentage: 90 },
    { name: 'React', percentage: 85 },
    { name: 'UI/UX Design', percentage: 80 },
    { name: 'TypeScript', percentage: 75 },
    { name: 'Node.js', percentage: 70 },
  ];

  return (
    <section id="about" className="bg-gray-800 py-20">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div>
            <h2 className="reveal text-3xl md:text-4xl font-bold mb-6">About Me</h2>
            <div className="reveal space-y-4">
              <p className="text-gray-300">
                Hi, I'm a passionate frontend developer with over 5 years of experience crafting
                beautiful and functional web experiences. I specialize in building responsive,
                user-friendly interfaces that deliver exceptional user experiences.
              </p>
              <p className="text-gray-300">
                My approach combines clean code, modern design principles, and performance
                optimization to create websites that not only look great but also convert visitors
                into customers.
              </p>
              <p className="text-gray-300">
                I pride myself on delivering high-quality work, maintaining clear communication, 
                and ensuring client satisfaction at every step of the development process.
              </p>
            </div>
            
            <div className="reveal mt-8">
              <h3 className="text-xl font-semibold mb-4">My Services</h3>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-primary-500 rounded-full mr-2"></span>
                  Website Development
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-primary-500 rounded-full mr-2"></span>
                  UI/UX Design
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-primary-500 rounded-full mr-2"></span>
                  Web App Development
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-primary-500 rounded-full mr-2"></span>
                  Performance Optimization
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-primary-500 rounded-full mr-2"></span>
                  E-Commerce Solutions
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-primary-500 rounded-full mr-2"></span>
                  CMS Integration
                </li>
              </ul>
            </div>
          </div>
          
          <div>
            <h3 className="reveal text-xl font-semibold mb-6">My Skills</h3>
            <div className="space-y-6">
              {skills.map((skill, index) => (
                <div 
                  key={skill.name} 
                  className="reveal"
                  style={{ transitionDelay: `${index * 100}ms` }}
                >
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{skill.name}</span>
                    <span className="text-gray-400">{skill.percentage}%</span>
                  </div>
                  <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-white rounded-full transition-all duration-1000 ease-out" 
                      style={{ width: '0%' }}
                      ref={el => {
                        if (el) {
                          setTimeout(() => {
                            el.style.width = `${skill.percentage}%`;
                          }, 300);
                        }
                      }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="reveal mt-10">
              <h3 className="text-xl font-semibold mb-4">Why Work With Me?</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-gray-700 bg-opacity-50 p-4 rounded-lg">
                  <h4 className="font-medium text-primary-400 mb-2">Client-Focused</h4>
                  <p className="text-sm text-gray-300">Your goals and satisfaction are my top priorities throughout the project.</p>
                </div>
                <div className="bg-gray-700 bg-opacity-50 p-4 rounded-lg">
                  <h4 className="font-medium text-primary-400 mb-2">Quality Assurance</h4>
                  <p className="text-sm text-gray-300">Rigorous testing ensures your project works flawlessly across all devices.</p>
                </div>
                <div className="bg-gray-700 bg-opacity-50 p-4 rounded-lg">
                  <h4 className="font-medium text-primary-400 mb-2">Affordable Rates</h4>
                  <p className="text-sm text-gray-300">Competitive pricing without compromising on quality or attention to detail.</p>
                </div>
                <div className="bg-gray-700 bg-opacity-50 p-4 rounded-lg">
                  <h4 className="font-medium text-primary-400 mb-2">Fast Turnaround</h4>
                  <p className="text-sm text-gray-300">Efficient workflow to deliver your project on time and within budget.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;