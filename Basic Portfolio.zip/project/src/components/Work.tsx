import React, { useEffect } from 'react';

interface Project {
  id: number;
  title: string;
  category: string;
  imageUrl: string;
  description: string;
}

const Work: React.FC = () => {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.reveal').forEach(el => {
      observer.observe(el);
    });

    return () => {
      document.querySelectorAll('.reveal').forEach(el => {
        observer.unobserve(el);
      });
    };
  }, []);

  const projects: Project[] = [
    {
      id: 1,
      title: "E-Commerce Platform",
      category: "Web Development",
      imageUrl: "https://images.pexels.com/photos/6956903/pexels-photo-6956903.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      description: "A modern e-commerce platform with seamless checkout experience and responsive design."
    },
    {
      id: 2,
      title: "Financial Dashboard",
      category: "UI/UX Design",
      imageUrl: "https://images.pexels.com/photos/7681679/pexels-photo-7681679.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      description: "Interactive dashboard providing real-time financial data visualization."
    },
    {
      id: 3,
      title: "Travel Booking App",
      category: "Mobile Development",
      imageUrl: "https://images.pexels.com/photos/3585089/pexels-photo-3585089.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      description: "User-friendly travel booking application with personalized recommendations."
    },
    {
      id: 4,
      title: "Creative Agency Website",
      category: "Web Development",
      imageUrl: "https://images.pexels.com/photos/5833891/pexels-photo-5833891.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      description: "Dynamic website for a creative agency with stunning animations and interactions."
    }
  ];

  return (
    <section id="work" className="bg-gray-900 py-20">
      <div className="container-custom">
        <h2 className="reveal section-heading">Featured Work</h2>
        <p className="reveal section-subheading">
          Take a look at some of my recent projects that showcase my skills and expertise.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
          {projects.map((project, index) => (
            <div 
              key={project.id}
              className="reveal group relative bg-gray-800 rounded-xl overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl"
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="aspect-w-16 aspect-h-9 relative overflow-hidden">
                <img 
                  src={project.imageUrl} 
                  alt={project.title} 
                  className="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent opacity-60"></div>
              </div>
              <div className="absolute inset-0 flex flex-col justify-end p-6">
                <span className="text-xs font-medium text-primary-400 mb-2">{project.category}</span>
                <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
                <p className="text-gray-400">{project.description}</p>
                <div className="mt-4 transform translate-y-8 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                  <a href="#" className="inline-flex items-center text-primary-400 hover:text-primary-300">
                    View Project 
                    <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                    </svg>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-16">
          <a href="#" className="btn bg-gray-800 hover:bg-gray-700 text-white">
            View All Projects
          </a>
        </div>
      </div>
    </section>
  );
};

export default Work;